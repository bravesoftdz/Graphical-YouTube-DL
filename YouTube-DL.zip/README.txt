If a youtube video/audio failes to download please check the github page for a update.

ALL FILES MUST BE IN THE SAME FOLDER!
